=begin
Cambiar while por times

i = 0
while i < 50
    puts "Iteración #{i}"
    i = i + 1
end
=end


50.times do |i|
    cont = i
    puts "Iteración #{cont}"   
end